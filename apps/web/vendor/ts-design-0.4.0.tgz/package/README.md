# tkos-ui · 天枢设计系统

`ts-design` · v0.4.0 · React 19 / HeroUI 3.2 / Tailwind CSS 4

源码：[TokenkingOS/tkos-ui](https://github.com/TokenkingOS/tkos-ui)（私有仓库，唯一维护入口）。仓库已从个人账号迁入组织；当前安装包与 CLI 名称仍为 `ts-design`。

一套可安装、可运行、可版本化的 Web 设计系统。以 CEO 手机体验为先，语音主操作、历史与键盘次级；阅读面稳定近白，功能层保留少量毛玻璃，健康状态仅使用局部淡洗色。为天枢概念版和 MVP 提供相同的主题、基础控件和交互契约。主题主色为天枢蓝 `#3A83F7`，配白字 `#FFFFFF`，辅助渐变色为 `#3C66BF`。

## 提供什么

- **主题**：浅色与深色、蓝色色阶、系统状态、业务语义、间距、圆角、尺寸和动效。JSON 是主题真源，CSS 自动生成。
- **基础控件**：优先直接复用 HeroUI 的 Button、Slider、Input、Card、Select、Modal 等；另有可选的 ActionButton、IconButton、FormField 便利组合。
- **公共模式**：玻璃通知卡、通知栏/窄条、战场翻面、全局输入条、证据、上下文输入、版本确认与工作区。
- **展示站**：主题 / 34 组独立组件样例 / 图形 / 设计规范 / 综合交互样板。手机、平板、电脑真实布局宽度预览；切换宽度保留进度。CEO/DRI 内容是公共结构用例，并非完整业务应用。
- **协作资料**：接入文档、组件 API、发布指南、变更日志、AI Skill，以及测试与持续集成配置。

组件不获取业务数据、不决定权限、不自动推进业务状态。示例数据只存在于 `site/`，不会打进公共组件代码。

## 开发者如何接入

### 1. 安装同一版本

首版通过版本化 `.tgz` 安装包分发，不依赖公共 npm 名称。将团队共享的安装包放入产品仓库 `vendor/`，一并提交并锁定依赖：

```sh
npm install ./vendor/ts-design-0.4.0.tgz
npm install react@19 react-dom@19 @heroui/react@3.2.5 @heroui/styles@3.2.5 tailwindcss@4
```

已有 React / HeroUI / Tailwind 时先核对版本，不要重复搭第二套 React。`ts-design` 是包的逻辑名称，尚未发布到公共 npm；请安装团队提供的文件，避免误装同名第三方包。私有 registry 的切换办法见 [发布与共享](docs/distribution.md)。

### 2. 引入 CSS 一次

在应用最外层入口引入，确保构建已配置 Tailwind CSS 4 的 Vite 插件或 PostCSS 插件：

```tsx
import 'ts-design/styles.css';
```

这个入口已经引入 Tailwind 与 HeroUI CSS，不需要再次全局引入它们。产品的全局样式放在其后。它包含全局 preflight：迁移旧应用时先用隔离样板路由验收，再扩大到已有页面。仅主题变量被限定在 `data-ts-theme` 范围内。

Vite 配置使用 `@tailwindcss/vite`；Next.js 在 PostCSS 中使用 `@tailwindcss/postcss`。不同工具链需要各自的插件，公共包不替产品修改构建配置。

### 3. 包住应用，使用公共组件

```tsx
'use client';
import { TianshuTheme, ActionButton, FormField } from 'ts-design';

export function App() {
  return (
    <TianshuTheme theme="light">
      <FormField label="议题标题" placeholder="本次需要决定什么？" />
      <ActionButton intent="primary" onPress={() => console.log('由应用处理')}>
        提交判断
      </ActionButton>
    </TianshuTheme>
  );
}
```

按钮统一使用 `onPress`；DOM ref 和 `data-*` 会保留。CSS 属性使用 `--ts-*`；页面通过布局 CSS 调整排列，不自行覆盖控件状态。

### 4. 接入工作区

```tsx
'use client';
import { useState } from 'react';
import {
  TianshuTheme,
  WorkspaceShell,
  NoticeCard,
  ContextComposer,
  useDetailNavigation,
} from 'ts-design';

export function Workspace() {
  const { detailId, open, close } = useDetailNavigation();
  const [drafts, setDrafts] = useState<Record<string, string>>({});
  const item = { id: 'delivery', title: '交付优先级' };
  return (
    <TianshuTheme>
      <WorkspaceShell
        roleLabel="CEO"
        noticeCount={1}
        onCloseDetail={close}
        sidebar={
          <NoticeCard
            category="issue"
            title={item.title}
            summary="客户验收时间重叠，需要明确取舍。"
            onOpen={(source) => open(item.id, source)}
          />
        }
        detail={
          detailId === item.id
            ? {
                id: item.id,
                title: item.title,
                children: (
                  <ContextComposer
                    context={item.title}
                    value={drafts[item.id] ?? ''}
                    onChange={(value) => setDrafts((old) => ({ ...old, [item.id]: value }))}
                    onSend={(value) => console.log('应用在这里调用真实服务', value)}
                  />
                ),
              }
            : null
        }
      >
        <h1>今日总览</h1>
      </WorkspaceShell>
    </TianshuTheme>
  );
}
```

`useDetailNavigation` 用于普通 React 页面。**Next / React Router 项目使用自身路由管理 detailId 和返回**，仍传给相同的 `WorkspaceShell`，不要混用两套路由。草稿由应用按对象保存；跨刷新持久化与多端同步也属于应用层。

## Agent 如何接入

安装后在产品仓库运行：

```sh
npx --no-install ts-design init
npx --no-install ts-design doctor
npx --no-install ts-design list
npx --no-install ts-design info Slider
```

init 为 AGENTS.md / CLAUDE.md 添加当前包的规则入口，保留原文且可重复执行。安装本身不会自动改项目。doctor 是静态配置检查；完成页面仍须类型检查和浏览器验收。

包内提供 [Agent 指南](AGENT_GUIDE.md)、[组件索引](components.json)、`examples/` 可编译例子、类型声明与 [参考实现](docs/references.md)。Agent 先读已安装版本，不依赖聊天记忆。

## 同事如何使用

| 人员           | 使用入口                    | 日常做法                                           |
| -------------- | --------------------------- | -------------------------------------------------- |
| 产品 / 设计    | 展示站                      | 查看状态、体验交互、比较不同宽度；用组件名描述变更 |
| 前端           | 安装包 + docs               | 固定版本引用组件和主题；集中升级                   |
| Claude / Codex | `skills/ts-design/SKILL.md` | 运行 init；读取 AGENT_GUIDE 与组件索引，再修改页面 |
| 维护者         | 本仓库                      | 修改主题源和公共实现，验证后发布新版本             |

## 本地运行本仓库

Node.js 22.12+，建议 Node 24；npm lockfile 已提交。

```sh
git clone https://github.com/TokenkingOS/tkos-ui.git
cd tkos-ui
npm ci
npm run build
npm run dev
```

展示站：`http://127.0.0.1:4178`。浏览器直接打开即可，无需安装客户端。手机真机验证时显式使用 `npm run dev -- --host 0.0.0.0`，在同一网络访问电脑局域网地址；不要把开发服务器当成正式服务。

```sh
npm run check          # 类型、单元测试、组件包和展示站生产构建
npx playwright install chromium
npm run test:e2e       # 浏览器交互与响应式验证
npm run bundle        # releases/ts-design-0.4.0.tgz
npm run verify:package # 在独立消费者中安装该包、核对类型并生产构建
```

`site-dist/` 为可部署的静态展示站，可部署在团队选定的静态托管服务。`dist/` 为 ESM、类型和 CSS。两个输出不能互相替代。

## 目录

```text
tokens/              主题真源（DTCG 结构的受支持子集）
src/                 组件、HeroUI 适配、公共交互与 CSS
site/                展示站和独立示例数据
assets/              品牌图形及来源说明
docs/                规范、API、接入、发布和验收
skills/              AI 使用说明
scripts/             token 编译、构建与分发工具
bin/                 Agent 接入与检查 CLI
examples/            随安装包发布的类型检查样例
tests/               单元与浏览器测试
.github/workflows/   CI 与按版本生成发布附件
```

## 进一步阅读

- [组件 API 与选型](docs/components.md)
- [设计原则与主题规则](docs/principles.md)
- [响应式、开合与草稿](docs/interaction.md)
- [从概念版接入](docs/migration.md)
- [发布、下载与版本纪律](docs/distribution.md)
- [验证范围与限制](docs/verification.md)
- [变更日志](CHANGELOG.md)

当前已按授权迁移本地 CEO 概念页的可替换控件，保留其空间和动效；它尚未整体依赖此公共包。旧 DRI/秘书页面未纳入这次迁移。具体范围见 [HeroUI 审查](docs/hero-audit.md)。

## 权利与来源

天枢自身代码和品牌资产默认保留所有权利，未授予对外开源许可。第三方依赖按各自许可证使用。见 [资产来源](assets/README.md)。
