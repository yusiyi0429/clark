# 现有天枢如何接入

## 先小范围使用

1. 现有仓库保存干净基线，安装明确版本的设计包；不要升级到未知的 HeroUI 主版本。
2. 建立隔离样板路由，接入 CSS 与 `TianshuTheme`。移除该路由重复的 HeroUI/Tailwind 引入。
3. 先迁移无复杂转场的表单或议题详情：优先直接使用 HeroUI Button / TextField 等，必要时用已有便利组合，只保留布局 CSS。
4. 将通知类别与状态映射到 NoticeCard；保留原业务对象 ID、权限和 onOpen 行为。
5. 单独迁移 WorkspaceShell。把原有路由、草稿容器和状态机接入 detail/onCloseDetail，删除重复的开合控制器后验收。
6. 完成一个路由后再扩大作用域。旧 CSS 的无层规则可能覆盖主题，因此必须比较实际 computed style 与状态。

## 旧变量映射

| 旧含义                 | 新变量          |
| ---------------------- | --------------- |
| paper / 页面底色       | --ts-bg         |
| surface / 正文表面     | --ts-surface    |
| ink / 主文字           | --ts-text       |
| ink-faint / 辅助文字   | --ts-text-muted |
| brand-deep / 主操作    | --ts-action     |
| confirmed / 已确认判断 | --ts-confirmed  |
| judgment / 尚待判断    | --ts-judgment   |
| counter / 反面依据     | --ts-counter    |

旧 `--muted`、`--accent` 的含义与 HeroUI 可能不同，不做全局搜索替换。业务 confirmed 与系统 success 分开，不因共享颜色而绑定状态。

## 接入验收

- 390 / 834 / 1440px 主界面无横向溢出；长标题可以换行。
- 主操作、禁用、错误、加载、选中和焦点可辨认；深色浮层正常。
- 浏览器返回、页面返回、Escape 一致；关闭再开不丢草稿。
- 中文输入法Enter不误发；触屏可以靠按钮完成核心操作。
- 现有数据请求、权限与决策状态不因组件替换而变化。
- 旧自定义动效若继续使用，应与新工作区编排择一，不能同时控制相同 DOM。

v0.2 的控件迁移曾保留原壁纸与战场状态色，此历史约定已被 v0.4 统一阅读面与局部状态规范覆盖；历史细节见 [审查记录](hero-audit.md)。公共包整体接入仍是独立迁移步骤，不能同时挂载旧控制器与 WorkspaceShell。旧 DRI/秘书页面没有在本轮统一替换。

v0.1 → v0.2：主色改为 #3A83F7 配白字；直接使用标准 HeroUI 控件；工作区恢复 690/1000 两个概念版断点，peek 改为覆盖抽屉；onOpen 可传源元素支持共享转场；战场新增翻面与进度参数。升级时检查原来依赖 700px 纵向堆叠的布局。

## v0.2 → v0.3 名称迁移

原包 `@tianshu/design-system` 改为 `ts-design`，原仓库 `tianshu-design-system` 改为 `ts-design`。卸载旧依赖，安装团队提供的 `ts-design-0.3.0.tgz`；import 前缀全部改成 `ts-design`，组件导出名称如 TianshuTheme 不变。命令改成 `npx --no-install ts-design init` / `doctor`，再次 init 会替换旧规则块。

## v0.3 → v0.4 统一体验

包和 CLI 继续使用 ts-design，仓库维护入口为 TokenkingOS/tkos-ui。升级至 ts-design-0.4.0.tgz 后移除消费者强制壁纸、类别正文渐变与整卡状态底色；采用 readingSurface 和 health* tokens。按业务数据传 BattlefieldCard.health，缺失保持 unknown。不要用 urgency 替代健康。

手机首页和平板总览的 dock 现在常驻；删除消费端重复的手机 dock 与固定底部留白。Shell 自动测量 dock。若示例使用语音提示回调，传明确的 voiceLabel/voiceHint。原 onVoice/onHistory API 兼容，未接入能力继续禁用。
