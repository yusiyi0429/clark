# 空间、开合与状态连续性

v0.4 以已认可的 CEO 开合与翻面交互为基准，恢复通知首页、阅读桌面、战场卡翻面和源卡片展开。组件示例仅使用本地数据，不复制业务后端。

## 响应式契约

| 状态     | ≤690 CSS px        | 691–1000 CSS px    | ≥1001 CSS px       |
| -------- | ------------------ | ------------------ | ------------------ |
| 总览     | 通知首页           | 双页阅读桌面       | 通知栏与全局战场   |
| 详情     | 48px 窄条与正文    | 窄条与正文         | 56px 窄条与正文    |
| 查看通知 | Drawer 覆盖正文    | Drawer 覆盖正文    | Drawer 覆盖正文    |
| 返回     | 通知首页与来源焦点 | 阅读桌面与来源焦点 | 战场总览与来源焦点 |

这是可用空间的断点，不做手机型号识别。登录无需选择设备。演示工具栏可选手机、平板、电脑及横竖屏；iframe 改变真实布局宽度并保留场景进度。使用 `tabletOverview` 提供专属阅读桌面；未提供时平板沿用普通总览，不复制一份 children。

通知与正文独立滚动；WorkspaceShell 使用可视窗口高度。长页面、无限列表、软键盘和嵌套容器仍需宿主验证。通知 peek 不改变正文 x 坐标和宽度，鼠标悬停不触发；点击窄条、Ctrl/Cmd+反斜线或左缘触屏滑动可展开，Escape 先关闭覆盖层。

## 哪些是自研

| 模式                           | 标准组件                                   | 天枢负责                           |
| ------------------------------ | ------------------------------------------ | ---------------------------------- |
| NoticeCard                     | Card / Chip / Button                       | 半透明玻璃标题、独立可读的正文托盘 |
| NotificationRail / NoticeStrip | Button / Drawer                            | 深蓝材质、时钟区域、窄条与空间协调 |
| BattlefieldCard                | Card / Button / ProgressCircle / Accordion | 正反面 3D 翻面与焦点衔接           |
| ConversationDock               | Button / TextField / TextArea              | 紧凑输入条到键盘输入面的形变       |
| WorkspaceShell                 | Drawer / Button                            | 侧栏、详情、来源卡片与返回联动     |

所有上述组件有独立样例。工作区综合样板验证组合关系；CEO/DRI 的示例内容只是使用场景，不代表完整产品页面。语音、锁定、持久化和真实确认由消费者提供；缺少能力的操作禁用，不假装已经执行。

## 源卡片展开与翻面

`NoticeCard.onOpen(source)` / `BattlefieldCard.onOpen(source)` 提供源节点。普通 React 应用调用 `useDetailNavigation().open(id, source)`；已有路由的项目使用自己的 router，并以 `runWorkspaceTransition(update, source, direction)` 包住同步状态更新。不要同时运行两套转场控制器。

优先使用 View Transitions 的源卡片与通知栏共享元素；不支持时使用 WAAPI FLIP（测量起止矩形进行位移与缩放）。新转场可跳过旧转场；减少动效时立即完成状态切换。动效不能触发确认或网络提交。

战场正反面在同一个测量区域内 rotateY 翻面。隐藏面必须同时 inert 和 aria-hidden；焦点转移到可见面的对应翻面键。缺少进度不是零进度，应显示“尚未评估”。

输入条两个表面常驻；切换显示不卸载输入。关闭键盘面后焦点回到键盘入口。中文组词期间 Enter 不发送，组合态、原生 isComposing 与兼容 keyCode 229 都要考虑。

## 返回与草稿

- 总览 DOM 保留，进入详情隐藏；返回恢复来源焦点。通知源节点重新挂载时按稳定标识重新定位。
- Escape 不覆盖子组件已处理的事件，不在组词时返回；打开 Modal / Drawer 时由浮层先处理。
- 轻量路由写入可返回的 URL 条目；切换详情替换当前条目，直达详情关闭时移除参数。已有路由的应用不混用轻量适配器。
- 草稿按对象 ID 存在应用层；关闭和改变宽度不能丢失。刷新持久化、权限、跨用户同步由业务层负责。
- `ContextComposer` 默认 Enter 换行；显式 sendOnEnter 时启用桌面发送快捷键。全局 ConversationDock 使用 Enter 发送、Shift+Enter 换行。

## 真机验证

电脑预览能验证布局、状态与流程。真实手机/iPad 的软键盘、Safari、旋转、分屏、安全区和帧率需要额外验证；不能把桌面 Chrome 模拟称为真机验收。

## v0.4 语音入口与底部空间

手机首页、平板总览和桌面均显示 ConversationDock；紧凑面仍显示当前讨论对象与能力说明。语音主按钮使用天枢蓝配白字，历史/键盘为中性次级，44px 热区。没有 onVoice 时语音禁用并显示未接入；示例使用“体验语音入口 / 未连接麦克风”，不请求麦克风。

WorkspaceShell 测量 dock 高度，为可滚动阅读区/手机通知列表预留相应底部空间，并包含 safe-area-inset-bottom。输入面保持常驻，关闭不丢草稿，Escape 先收起输入面，再允许工作区返回。极小屏、真实软键盘与 Safari visual viewport 仍须真机检查。

手机总览的通知首页使用浅冷灰画布（深色用中性深底），玻璃标题保留深色半透明底与白字，顶部按钮用中性主题；独立 NotificationRail、桌面通知栏、Drawer 和窄条仍保留深蓝材质。
