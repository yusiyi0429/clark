# HeroUI 复用与概念版对照

审查基准：本地 clark-main 的 CEO 概念页、HeroUI 3.2.5 类型与样式。库实现版本 v0.2.0。以下为历史迁移记录；v0.4 的最新表面/状态规则见 docs/principles.md，不再沿用整卡状态底色和壁纸约定。

## 本库

展示站有 34 个独立样例入口：24 组直接 HeroUI 控件，10 组天枢组合或自研材质/动效。另有综合工作区样板。这个数字是样例覆盖数，不是按代码行推算的复用比例。

直接组件包括 Button、TextField/Input/TextArea、Slider、Switch、Checkbox、Radio、Select/ListBox、Tabs、ToggleButton、Card、Chip、Modal、Drawer、Tooltip、Popover、Accordion、Progress、Avatar、Skeleton/Spinner、Alert、NumberField、SearchField、Separator。导出与示例详见 components.json。

天枢组合中的标准内部控件同样来自 HeroUI。保留自研的是玻璃材质、rail/strip、翻面、源卡片过渡和输入条形变。v0.1 的红色卡片顶框已移除，普通控件不再用自绘样式盖过 HeroUI。

## 概念版本轮迁移

- 活跃 CEO 界面新增替换 63 处原生按钮、6 处文本输入；包括通知、全局输入、群聊、战场、雷达内容入口、月度任务与引用操作。
- 内容按钮使用很薄的 HeroButton 适配，保留 onClick、ref、data-*；title 提示交给 HeroUI Tooltip。普通 Button 保留原版 API。
- 监测范围改用 HeroUI Modal；输入、按钮和焦点管理交给套件，保留已有退出动效。
- 通知卡与战场正反面容器使用 HeroUI Card；玻璃 header 使用 Card.Header，原有 DOM 语义和测量层保持。
- 主动作对齐 #3A83F7 / 白字；原有战场状态色不变。

本轮统计的是新增迁移，不把之前已使用的 HeroUI 重复计入。该概念页的 HeroUI CSS 仍由其现有主题桥接；尚未把整个旧应用改为安装公共包，避免同时运行两套工作区控制器。

## 有意保留

| 内容                                    | 理由                                                        |
| --------------------------------------- | ----------------------------------------------------------- |
| sidebar / tail strip / 源卡片与通知联动 | 产品空间协调没有现成等价控件                                |
| 3D 翻面测量层、输入条双层形变           | 已通过概念演示认可，需要保持几何与状态连续性                |
| 非模态的通知/内容返回遮罩               | 是原编排的命中区域，不作为普通业务按钮展示                  |
| 业务进度图、图形与数据表面              | 具有产品含义，不能用无关示例替代                            |
| heavy-workspace 中不再挂载的旧界面      | 活跃页面仅复用其数据工具；没有把死代码计为迁移完成          |
| 旧 DRI / 秘书 / 五环节界面              | 与本轮 CEO 概念页不是同一套主题，未进行未经回归的大范围替换 |

后续新增标准控件优先 HeroUI。任何新自研控件须说明上游缺口并增加独立示例。完整真实产品流程仍需各产品仓库的业务测试。
