# 参考实现与取舍

只参考组织与接入方式，未把其他库的组件视觉混入天枢。

| 项目                                                                           | 参考内容                                        | 本库对应                                        |
| ------------------------------------------------------------------------------ | ----------------------------------------------- | ----------------------------------------------- |
| [GitHub Primer React](https://github.com/primer/react)                         | 公共 React 包、组件示例、类型与测试、组件元数据 | src / site / tests / components.json 同版本发布 |
| [Microsoft Fluent UI](https://github.com/microsoft/fluentui)                   | 包与文档分层、应用示例、仓库 Agent 规则         | examples / docs / AGENT_GUIDE.md / init         |
| [IBM Carbon](https://github.com/carbon-design-system/carbon)                   | 多包组织与共享基础                              | 先保留一个小而完整的发布包，规模需要时再拆包    |
| [HeroUI Agent 文档](https://heroui.com/en/docs/react/getting-started/llms-txt) | 给 Agent 的组件与完整文档入口                   | llms.txt / 组件索引 / 当前版本类型 / 可编译样例 |

本库使用 HeroUI 3.2.5 作为唯一通用控件底座。不会因为参考了 Primer/Fluent 就再安装另一套 Button。

`npm install` 只能安装依赖，不能保证所有 Agent 自动读取规范。因此提供显式 `ts-design init`，把入口加入项目 AGENTS.md 与 CLAUDE.md，并保留原规则。`list` / `info` 给出可检索组件，`doctor` 检查基础接入。安装时不偷偷改项目文件；展示样例随包发布并在独立消费者里编译。

完整目录、源码、构建脚本与发布记录属于 Git 仓库；消费者依赖已打包版本。README 面向人，结构化索引面向工具，Skill 负责查阅流程，三者指向同一套实际组件与 token。
