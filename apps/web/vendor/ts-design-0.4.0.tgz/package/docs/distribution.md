# 发布、下载与共享

## 首版渠道

GitHub 源码仓库：[TokenkingOS/tkos-ui](https://github.com/TokenkingOS/tkos-ui)，可见性为私有，是后续唯一维护入口。仓库已从个人账号转入组织并重命名，完整 Git 历史保留；旧仓库地址会跳转到此处。当前安装包、import 和 CLI 名称仍为 `ts-design`，仓库迁移不改变消费者的接入方式。

已有本地克隆更新远端地址：

```sh
git remote set-url origin https://github.com/TokenkingOS/tkos-ui.git
git fetch origin
```

当前配置采用私有协作的本地包 / GitHub Release 附件方案。`npm pack` 生成 `.tgz`，可下载、归档、提交到消费者 vendor/，安装时不需要额外 registry 权限。仅运行 npm pack 不会向外发布。

`ts-design` 暂作为安装包名称，不表示拥有公共 npm 的同名包。包没有配置公共 registry 发布，prepublishOnly 主动阻止误发。

## 版本纪律

- v0.x：兼容修补升 patch；新增或不兼容变更升 minor，必须写迁移说明。
- 稳定到 v1 后：破坏 API / token 含义 / 交互契约升 major，新增向后兼容内容升 minor，修补升 patch。
- README、package.json、主题导出、展示站版本号、CHANGELOG 保持一致。生成 token 的版本应从 package.json 读取。
- 概念版和 MVP 各自固定版本及 lockfile。概念版先体验新版本；MVP 在回归通过后升级。
- 不复制 src/ 到多个仓库，不把 branch main 当成可重复构建的依赖版本。

## 本地分发

```sh
npm ci
npm run check
npm run test:e2e
npm run bundle
```

输出 `releases/ts-design-0.4.0.tgz`。同事安装前可以用团队记录的 SHA256 校验，包内容包含 dist/docs/tokens/assets/skills/README/CHANGELOG，以及 bin、examples、components.json、llms.txt、AGENT_GUIDE.md。

## GitHub 自动发布

`.github/workflows/ci.yml` 对 PR 和 push 做类型、测试、生产构建和浏览器检查。

`.github/workflows/release.yml` 在推送 `v*` tag 后验证 tag 与 package.json 匹配，生成 `.tgz` 和展示站 `.zip`，写入 GitHub Release 附件。工作流仅在仓库实际存在且启用 Actions 后工作；文件存在不表示已经对外发布。

仓库可先为私有，邀请同事后共享展示站链接和 release。静态展示站的托管位置、访问控制须跟团队环境一致，本仓库不自动把内容发布到公开网站。

## 将来切换私有 registry

团队确定账号、组织和权限后再改发布渠道：

1. GitHub Packages 要使用 GitHub 用户/组织 scope；本仓库属于 TokenkingOS，可采用 `@tokenkingos/tkos-ui`，消费者 import 和文档同步调整。此名称是未来渠道示例，尚未发布。
2. npm 私有包需要有权限的组织 scope，可采用 `@tianshu/ts-design`；如使用自管私有 registry，可保留 `ts-design`。名称与 import 应一起迁移。
3. 配置 registry 与最小权限的发布凭据，使用 CI secrets，不能提交 token。
4. 增加包下载权限与新同事安装说明，验证清空缓存后的安装。
5. 审核完成后替换 `prepublishOnly` 保护脚本，并发布一个明确版本。

公共组件 API 不因存储渠道改变而变化。消费仓库应通过版本升级接收改动。
