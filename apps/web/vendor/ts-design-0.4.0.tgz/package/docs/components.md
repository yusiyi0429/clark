# 组件选型与 API

完整 TypeScript 类型随 `dist/*.d.ts` 发布。参数与示例代码以安装的版本为准。

| 组件                | 用途                         | 关键参数                                                                                               |
| ------------------- | ---------------------------- | ------------------------------------------------------------------------------------------------------ |
| TianshuTheme        | 本地主题边界                 | theme: light/dark；motion: system/reduced；默认 light/system                                           |
| TianshuPortalTheme  | 浮层内容主题                 | React 上下文继承最近的主题；放在 portal 内部                                                           |
| ActionButton        | 统一操作层级                 | intent: primary/secondary/quiet/danger；其余沿用 HeroUI Button，如 onPress、isDisabled、isPending、ref |
| IconButton          | 纯图标操作                   | label 必填，子元素为图标；至少44px                                                                     |
| FormField           | 已关联 label/说明/错误的字段 | label、value/onChange、description、error、multiline、rows；只读/禁用沿用 HeroUI TextField             |
| StatusBadge         | 有文字的状态标签             | tone: neutral/info/success/warning/danger                                                              |
| NoticeCard          | 三类重要事项                 | category: decision/meeting/issue；title、summary、meta、status、tone、onOpen、isSelected               |
| BattlefieldCard     | 战场当前判断                 | title、summary、urgency、reason、decision、onOpen(source)、progress、health、goal、mode/onModeChange   |
| EvidenceItem        | 可追溯依据                   | title、source、date、excerpt、supports、limitation、href、status                                       |
| StatePanel          | 工作区空/加载/错误/只读提示  | state、title、children、onRetry                                                                        |
| ContextComposer     | 已绑定对象的输入             | context、value/onChange、onSend、state、error、onRetry、onStop、sendOnEnter                            |
| VersionConfirmation | 对指定版本明确确认           | version、summary、state: pending/confirmed/stale、onConfirm                                            |
| WorkspaceShell      | 事项栏+总览+详情             | roleLabel、sidebar、noticeCount、detail、onCloseDetail、children、tabletOverview、dock、onLock         |
| useDetailNavigation | 普通React的轻量详情路由      | 参数名默认detail；返回detailId/open(id, source?)/close；每个页面使用一个实例                           |

## 公共交互组件

| 组件                    | 关键参数与边界                                                                                    |
| ----------------------- | ------------------------------------------------------------------------------------------------- |
| NotificationGlassHeader | category、meta；HeroUI Card.Header + 玻璃材质                                                     |
| NotificationRail        | children、title、date、onHome、onLock；日期由应用传入                                             |
| NoticeStrip             | expanded、noticeCount、currentLabel、onToggle、onHome、onLock、controls                           |
| ConversationDock        | value/onChange、onSend、context、caption、onVoice、voiceLabel、voiceHint、onHistory；无能力时禁用 |
| runWorkspaceTransition  | 同步 update、source、open/close；由应用决定路由与业务状态                                         |

`components.json` 可机读；CLI `info` 给出来源、入口、示例与规则。`examples/start.tsx` 是最小接入，`component-stories.tsx` 覆盖全部独立样例，`workspace-demo.tsx` 展示组合。

## 状态由应用控制

- Composer 的 `onSend` 只报告输入，不自动清空。请求成功后由应用清空；失败保留输入并设置 error；生成时改为 generating 并提供 onStop。
- Composer 默认 Enter 换行。桌面显式传 sendOnEnter 后 Enter 发送、Shift+Enter 换行，中文组词期间仍不发送。
- VersionConfirmation 的 confirmed 必须来自可信的业务状态。请求发起不等于确认成功；业务可在外层加载/禁用期间替换为 StatePanel。
- NoticeCard 打开事件不标记已处理，不替应用作权限判断。
- EvidenceItem 原文按纯文本展示并保留换行，不渲染任意 HTML。只允许 http/https 与站内绝对路径链接。
- 页面使用长文档、Markdown 或图表时自行提供经过安全处理的内容组件；不要强行把它们塞成文本标签。

## 直接复用 HeroUI

从 `ts-design/primitives` 导入 Button、Card、Chip、Slider、Input、TextArea、TextField、Label、Description、FieldError、Tabs、ToggleButton、ToggleButtonGroup、Switch、Checkbox/CheckboxGroup、Radio/RadioGroup、Select/ListBox、Modal、Drawer、Tooltip、Popover、Spinner、Skeleton、Separator、Avatar、Accordion、ProgressBar/ProgressCircle、Alert、NumberField、SearchField、CloseButton、ScrollShadow。这些保留上游 API，不重新包装改名。

基础库没有覆盖的输入类型可直接使用同版本 `@heroui/react`，主题仍然生效。高风险或重复模式通过公共系统扩展；不要以“统一”为由封装每一个组件。

### 弹窗

```tsx
import { Modal } from 'ts-design/primitives';
import { TianshuPortalTheme } from 'ts-design';

<Modal isOpen={open} onOpenChange={setOpen}>
  <Modal.Backdrop>
    <TianshuPortalTheme>
      <Modal.Container>
        <Modal.Dialog>
          <Modal.CloseTrigger />
          <Modal.Header>
            <Modal.Heading>确认范围</Modal.Heading>
          </Modal.Header>
          <Modal.Body>内容</Modal.Body>
        </Modal.Dialog>
      </Modal.Container>
    </TianshuPortalTheme>
  </Modal.Backdrop>
</Modal>;
```

原生 HTML 保留语义结构，如 article、main、blockquote。无需把所有容器替换为 HeroUI Card 才算统一。

### v0.4 语义与兼容性

BattlefieldCard 新增可选 health: healthy / watch / risk / unknown，默认 unknown。健康数据由应用明确传入，与 urgency、progress 和确认互不推断。局部状态洗色使用主题 token。

ConversationDock 新增 voiceLabel（默认“开始语音输入”）、voiceHint。演示回调应写“体验语音入口”与“未连接麦克风”；缺少 onVoice 自动禁用。context 在紧凑与键盘面均可辨认。WorkspaceShell 将 dock 保持在同一 DOM 节点，全部宽度可见并测量底部占位；消费者不需要额外渲染手机副本。
