// Published from site/start-example.tsx; validated with the library's typecheck.
'use client';
import { useState } from 'react';
import { X } from 'lucide-react';
import {
  TianshuTheme,
  TianshuPortalTheme,
  ActionButton,
  IconButton,
  FormField,
  StatusBadge,
} from 'ts-design';
import { Modal, Slider, Label } from 'ts-design/primitives';

/** Import ts-design/styles.css once in the application's root entry. */
export function StartExample() {
  const [title, setTitle] = useState('');
  const [open, setOpen] = useState(false);
  return (
    <TianshuTheme theme="light">
      <FormField label="议题标题" value={title} onChange={setTitle} />
      <Slider aria-label="优先级" defaultValue={60}>
        <Label>优先级</Label>
        <Slider.Track>
          <Slider.Fill />
          <Slider.Thumb />
        </Slider.Track>
      </Slider>
      <StatusBadge tone="info">待讨论</StatusBadge>
      <ActionButton intent="primary" onPress={() => setOpen(true)}>
        预览议题
      </ActionButton>
      <Modal isOpen={open} onOpenChange={setOpen}>
        <Modal.Backdrop>
          <TianshuPortalTheme>
            <Modal.Container>
              <Modal.Dialog>
                <Modal.Header>
                  <Modal.Heading>{title || '未命名议题'}</Modal.Heading>
                  <IconButton label="关闭预览" onPress={() => setOpen(false)}>
                    <X size={18} />
                  </IconButton>
                </Modal.Header>
                <Modal.Body>业务权限与提交由应用处理。</Modal.Body>
              </Modal.Dialog>
            </Modal.Container>
          </TianshuPortalTheme>
        </Modal.Backdrop>
      </Modal>
    </TianshuTheme>
  );
}
