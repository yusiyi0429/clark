// Published from site/stories.tsx; validated with the library's typecheck.
import { useState } from 'react';
import {
  Button,
  Card,
  Chip,
  Slider,
  TextField,
  Input,
  TextArea,
  Label,
  Description,
  FieldError,
  Switch,
  Checkbox,
  Radio,
  RadioGroup,
  Select,
  ListBox,
  Tabs,
  ToggleButton,
  ToggleButtonGroup,
  Modal,
  Drawer,
  Tooltip,
  Popover,
  Accordion,
  ProgressBar,
  ProgressCircle,
  Avatar,
  Skeleton,
  Spinner,
  Separator,
  Alert,
  NumberField,
  SearchField,
} from 'ts-design/primitives';
import {
  NoticeCard,
  NotificationRail,
  NoticeStrip,
  NotificationGlassHeader,
  BattlefieldCard,
  ConversationDock,
  ContextComposer,
  EvidenceItem,
  StatePanel,
  VersionConfirmation,
  TianshuPortalTheme,
} from 'ts-design';
import { Plus, Minus, X, Search, Check, PanelLeft, Send } from 'lucide-react';
export const stories = [
  ['button', 'Button', '按钮', 'HeroUI'],
  ['input', 'TextField / Input', '输入框', 'HeroUI'],
  ['textarea', 'TextArea', '多行输入', 'HeroUI'],
  ['slider', 'Slider', '滑块', 'HeroUI'],
  ['switch', 'Switch', '开关', 'HeroUI'],
  ['checkbox', 'Checkbox', '复选框', 'HeroUI'],
  ['radio', 'RadioGroup', '单选', 'HeroUI'],
  ['select', 'Select / ListBox', '选择器', 'HeroUI'],
  ['tabs', 'Tabs', '页签', 'HeroUI'],
  ['toggle', 'ToggleButtonGroup', '分段选择', 'HeroUI'],
  ['card', 'Card', '卡片', 'HeroUI'],
  ['chip', 'Chip', '状态标记', 'HeroUI'],
  ['modal', 'Modal', '弹窗', 'HeroUI'],
  ['drawer', 'Drawer', '抽屉', 'HeroUI'],
  ['tooltip', 'Tooltip', '提示', 'HeroUI'],
  ['popover', 'Popover', '浮层', 'HeroUI'],
  ['accordion', 'Accordion', '折叠内容', 'HeroUI'],
  ['progress', 'ProgressBar / ProgressCircle', '进度', 'HeroUI'],
  ['avatar', 'Avatar', '头像', 'HeroUI'],
  ['loading', 'Skeleton / Spinner', '加载状态', 'HeroUI'],
  ['alert', 'Alert', '提示信息', 'HeroUI'],
  ['number', 'NumberField', '数值输入', 'HeroUI'],
  ['search', 'SearchField', '搜索', 'HeroUI'],
  ['separator', 'Separator', '分隔线', 'HeroUI'],
  ['glass', 'NotificationGlassHeader', '毛玻璃标题区', '组合'],
  ['notice', 'NoticeCard', '通知卡', '组合'],
  ['rail', 'NotificationRail', '通知栏', '自研结构'],
  ['strip', 'NoticeStrip', '通知窄条', '自研结构'],
  ['battlefield', 'BattlefieldCard', '战场翻面', '组合 + 自研动效'],
  ['dock', 'ConversationDock', '底部输入条', '组合 + 自研动效'],
  ['composer', 'ContextComposer', '上下文输入', '组合'],
  ['evidence', 'EvidenceItem', '证据卡', '组合'],
  ['confirmation', 'VersionConfirmation', '版本确认', '组合'],
  ['state', 'StatePanel', '空态与错误', '组合'],
] as const;
export type StoryId = (typeof stories)[number][0];
export const storyReasons: Partial<Record<StoryId, string>> = {
  glass: 'Card.Header 的材质扩展：复用概念版壁纸上的透明、模糊、亮边与独立阅读托盘。',
  rail: '通知栏承担壁纸、顶部浮动操作和独立滚动。它不是导航菜单。内部卡片和按钮来自 HeroUI。',
  strip:
    '通知栏收缩后的持久入口；点击、快捷键或边缘轻扫呼出覆盖层。HeroUI 负责按钮和 Drawer，天枢负责空间联动。',
  battlefield:
    'HeroUI Card、Button、ProgressCircle、Accordion 负责内容；天枢只保留 3D 翻面、inert 与焦点交接。',
  dock: 'HeroUI Button、TextField、TextArea 负责输入；天枢保留两层同平面的形变。草稿、语音和记录由应用提供。',
};
export function NoticeSample({ onOpen = () => {} }: { onOpen?: (source?: HTMLElement) => void }) {
  return (
    <NoticeCard
      category="decision"
      title="确认下一阶段的验证重心"
      summary="先完成灯塔客户的自主使用验证，再扩大交付范围。请核对会后共识。"
      meta="09:20"
      status="待确认"
      onOpen={onOpen}
    />
  );
}
export function PrimitiveStory({ id }: { id: StoryId }) {
  const [value, setValue] = useState(''),
    [selected, setSelected] = useState(false),
    [open, setOpen] = useState(false),
    [notice, setNotice] = useState(''),
    [confirmed, setConfirmed] = useState(false);
  const state = (
    <p className="story-feedback" role="status">
      {notice}
    </p>
  );
  const submit = (text: string) => {
    setNotice(`已记录：${text}`);
    setValue('');
  };
  let example;
  switch (id) {
    case 'button':
      example = (
        <>
          <div className="ts-row">
            {(['primary', 'secondary', 'tertiary', 'ghost', 'danger-soft'] as const).map(
              (variant) => (
                <Button
                  key={variant}
                  variant={variant}
                  onPress={() => setNotice(`点击了 ${variant}`)}
                >
                  {variant === 'primary'
                    ? '主要操作'
                    : variant === 'secondary'
                      ? '次要操作'
                      : variant === 'tertiary'
                        ? '轻操作'
                        : variant === 'ghost'
                          ? '文字操作'
                          : '删除'}
                </Button>
              ),
            )}
          </div>
          <div className="ts-row">
            <Button isDisabled>不可操作</Button>
            <Button isIconOnly aria-label="添加" onPress={() => setNotice('已添加')}>
              <Plus size={18} />
            </Button>
            <Button>
              <Spinner size="sm" />
              正在保存
            </Button>
          </div>
        </>
      );
      break;
    case 'input':
      example = (
        <>
          <TextField value={value} onChange={setValue}>
            <Label>议题名称</Label>
            <Input placeholder="需要做出的决定" />
            <Description>一句话说明需要明确什么。</Description>
          </TextField>
          <TextField isInvalid>
            <Label>负责人</Label>
            <Input placeholder="选择负责人" />
            <FieldError>请指定一位负责人</FieldError>
          </TextField>
        </>
      );
      break;
    case 'textarea':
      example = (
        <TextField value={value} onChange={setValue}>
          <Label>补充依据</Label>
          <TextArea rows={4} placeholder="写下事实、来源与仍不确定的地方…" />
          <Description>保留换行；支持中文输入。</Description>
        </TextField>
      );
      break;
    case 'slider':
      example = (
        <>
          <Slider defaultValue={65}>
            <Label>显示密度</Label>
            <Slider.Output />
            <Slider.Track>
              <Slider.Fill />
              <Slider.Thumb />
            </Slider.Track>
          </Slider>
          <Slider defaultValue={[25, 75]}>
            <Label>时间范围</Label>
            <Slider.Output />
            <Slider.Track>
              <Slider.Fill />
              <Slider.Thumb index={0} />
              <Slider.Thumb index={1} />
            </Slider.Track>
          </Slider>
        </>
      );
      break;
    case 'switch':
      example = (
        <Switch isSelected={selected} onChange={setSelected}>
          <Switch.Control>
            <Switch.Thumb />
          </Switch.Control>
          <Switch.Content>
            <Label>接收更新提醒</Label>
            <Description>仅提醒当前关注的议题。</Description>
          </Switch.Content>
        </Switch>
      );
      break;
    case 'checkbox':
      example = (
        <Checkbox isSelected={selected} onChange={setSelected}>
          <Checkbox.Control>
            <Checkbox.Indicator />
          </Checkbox.Control>
          <Checkbox.Content>
            <Label>我已核对本次材料</Label>
            <Description>打开材料不会自动确认。</Description>
          </Checkbox.Content>
        </Checkbox>
      );
      break;
    case 'radio':
      example = (
        <RadioGroup defaultValue="daily">
          <Label>提醒频率</Label>
          {[
            ['daily', '每日摘要'],
            ['urgent', '仅紧急事项'],
          ].map(([key, label]) => (
            <Radio value={key} key={key}>
              <Radio.Control>
                <Radio.Indicator />
              </Radio.Control>
              <Radio.Content>
                <Label>{label}</Label>
              </Radio.Content>
            </Radio>
          ))}
        </RadioGroup>
      );
      break;
    case 'select':
      example = (
        <Select placeholder="选择战场">
          <Label>关注范围</Label>
          <Select.Trigger>
            <Select.Value />
            <Select.Indicator />
          </Select.Trigger>
          <Select.Popover>
            <TianshuPortalTheme>
              <ListBox>
                {['灯塔项目', 'TokenOps', '公司能力'].map((title) => (
                  <ListBox.Item key={title} id={title} textValue={title}>
                    {title}
                    <ListBox.ItemIndicator />
                  </ListBox.Item>
                ))}
              </ListBox>
            </TianshuPortalTheme>
          </Select.Popover>
        </Select>
      );
      break;
    case 'tabs':
      example = (
        <Tabs>
          <Tabs.ListContainer>
            <Tabs.List aria-label="议题详情">
              <Tabs.Tab id="judgment">
                判断
                <Tabs.Indicator />
              </Tabs.Tab>
              <Tabs.Tab id="evidence">
                依据
                <Tabs.Indicator />
              </Tabs.Tab>
            </Tabs.List>
          </Tabs.ListContainer>
          <Tabs.Panel id="judgment">先看当前判断，再决定下一步。</Tabs.Panel>
          <Tabs.Panel id="evidence">材料来自客户访谈与试用记录。</Tabs.Panel>
        </Tabs>
      );
      break;
    case 'toggle':
      example = (
        <ToggleButtonGroup
          selectionMode="single"
          disallowEmptySelection
          defaultSelectedKeys={['decisions']}
          aria-label="战场展示方式"
        >
          <ToggleButton id="decisions">待决策</ToggleButton>
          <ToggleButton id="progress">进展</ToggleButton>
        </ToggleButtonGroup>
      );
      break;
    case 'card':
      example = (
        <Card>
          <Card.Header>
            <Card.Title>本周材料已更新</Card.Title>
            <Card.Description>三条议题，两个决策点。</Card.Description>
          </Card.Header>
          <Card.Content>
            <p>卡片使用 HeroUI 默认的间距、圆角与表面。页面只决定它摆在哪里。</p>
          </Card.Content>
          <Card.Footer>
            <Button variant="secondary" onPress={() => setNotice('已打开材料')}>
              查看材料
            </Button>
          </Card.Footer>
        </Card>
      );
      break;
    case 'chip':
      example = (
        <div className="ts-row">
          {(['default', 'accent', 'success', 'warning', 'danger'] as const).map((color, i) => (
            <Chip key={color} color={color} variant="soft">
              {['待处理', '已选中', '已完成', '需关注', '有阻塞'][i]}
            </Chip>
          ))}
        </div>
      );
      break;
    case 'modal':
      example = (
        <>
          <Button onPress={() => setOpen(true)}>打开确认弹窗</Button>
          <Modal isOpen={open} onOpenChange={setOpen}>
            <Modal.Backdrop>
              <TianshuPortalTheme>
                <Modal.Container>
                  <Modal.Dialog>
                    <Modal.CloseTrigger />
                    <Modal.Header>
                      <Modal.Heading>确认当前版本</Modal.Heading>
                    </Modal.Header>
                    <Modal.Body>确认只针对当前内容；后续修订会重新请求确认。</Modal.Body>
                    <Modal.Footer>
                      <Button variant="secondary" onPress={() => setOpen(false)}>
                        取消
                      </Button>
                      <Button
                        onPress={() => {
                          setOpen(false);
                          setNotice('已确认此版本');
                        }}
                      >
                        确认
                      </Button>
                    </Modal.Footer>
                  </Modal.Dialog>
                </Modal.Container>
              </TianshuPortalTheme>
            </Modal.Backdrop>
          </Modal>
        </>
      );
      break;
    case 'drawer':
      example = (
        <>
          <Button onPress={() => setOpen(true)}>打开材料抽屉</Button>
          <Drawer isOpen={open} onOpenChange={setOpen}>
            <Drawer.Backdrop>
              <TianshuPortalTheme>
                <Drawer.Content>
                  <Drawer.Dialog>
                    <Drawer.CloseTrigger />
                    <Drawer.Header>
                      <Drawer.Heading>相关材料</Drawer.Heading>
                    </Drawer.Header>
                    <Drawer.Body>HeroUI 负责焦点、Escape 与背景点击关闭。</Drawer.Body>
                  </Drawer.Dialog>
                </Drawer.Content>
              </TianshuPortalTheme>
            </Drawer.Backdrop>
          </Drawer>
        </>
      );
      break;
    case 'tooltip':
      example = (
        <Tooltip>
          <Tooltip.Trigger aria-label="发送">
            <Send size={20} />
          </Tooltip.Trigger>
          <Tooltip.Content>发送当前消息</Tooltip.Content>
        </Tooltip>
      );
      break;
    case 'popover':
      example = (
        <Popover>
          <Popover.Trigger>查看说明</Popover.Trigger>
          <Popover.Content>
            <TianshuPortalTheme>
              <Popover.Dialog className="story-popover">
                所有判断都应该保留证据来源。
              </Popover.Dialog>
            </TianshuPortalTheme>
          </Popover.Content>
        </Popover>
      );
      break;
    case 'accordion':
      example = (
        <Accordion>
          {['为什么重要', '需要明确什么'].map((title) => (
            <Accordion.Item key={title}>
              <Accordion.Heading>
                <Accordion.Trigger>
                  {title}
                  <Accordion.Indicator />
                </Accordion.Trigger>
              </Accordion.Heading>
              <Accordion.Panel>
                <Accordion.Body>客户验证窗口正在缩短，需要明确下一步的资源投入。</Accordion.Body>
              </Accordion.Panel>
            </Accordion.Item>
          ))}
        </Accordion>
      );
      break;
    case 'progress':
      example = (
        <>
          <ProgressBar value={62}>
            <Label>交付进展</Label>
            <ProgressBar.Output />
            <ProgressBar.Track>
              <ProgressBar.Fill />
            </ProgressBar.Track>
          </ProgressBar>
          <ProgressCircle value={62} aria-label="月度进展">
            <ProgressCircle.Track>
              <ProgressCircle.TrackCircle />
              <ProgressCircle.FillCircle />
            </ProgressCircle.Track>
          </ProgressCircle>
        </>
      );
      break;
    case 'avatar':
      example = (
        <div className="ts-row">
          <Avatar>
            <Avatar.Fallback>陈</Avatar.Fallback>
          </Avatar>
          <Avatar>
            <Avatar.Fallback>李</Avatar.Fallback>
          </Avatar>
        </div>
      );
      break;
    case 'loading':
      example = (
        <>
          <Spinner />
          <Skeleton style={{ height: 20, width: '60%' }} />
          <Skeleton style={{ height: 80, width: '100%' }} />
        </>
      );
      break;
    case 'alert':
      example = (
        <Alert status="success">
          <Alert.Indicator />
          <Alert.Content>
            <Alert.Title>共识已保存</Alert.Title>
            <Alert.Description>负责人将基于这一版继续推进。</Alert.Description>
          </Alert.Content>
        </Alert>
      );
      break;
    case 'number':
      example = (
        <NumberField defaultValue={3} minValue={1} maxValue={10}>
          <Label>提前提醒天数</Label>
          <NumberField.Group>
            <NumberField.DecrementButton />
            <NumberField.Input />
            <NumberField.IncrementButton />
          </NumberField.Group>
        </NumberField>
      );
      break;
    case 'search':
      example = (
        <SearchField value={value} onChange={setValue}>
          <Label>搜索材料</Label>
          <SearchField.Group>
            <SearchField.SearchIcon />
            <SearchField.Input placeholder="输入关键词" />
            <SearchField.ClearButton />
          </SearchField.Group>
        </SearchField>
      );
      break;
    case 'separator':
      example = (
        <>
          <p>当前判断</p>
          <Separator />
          <p>支持判断的材料</p>
        </>
      );
      break;
    case 'glass':
      example = (
        <div className="story-wallpaper">
          <NotificationGlassHeader category="decision" meta="09:20" />
        </div>
      );
      break;
    case 'notice':
      example = (
        <div className="story-wallpaper">
          <NoticeSample onOpen={() => setNotice('打开当前共识详情')} />
        </div>
      );
      break;
    case 'rail':
      example = (
        <div className="story-rail">
          <NotificationRail>
            <NoticeSample onOpen={() => setNotice('打开当前共识详情')} />
            <NoticeCard
              category="meeting"
              title="CEO / DRI 战略协同会议"
              summary="先明确验证目标，再确认本周决策点。"
              meta="10:00"
              status="待预审"
              onOpen={() => setNotice('打开会议预审')}
            />
          </NotificationRail>
        </div>
      );
      break;
    case 'strip':
      example = (
        <div className="story-strip">
          <NoticeStrip
            onHome={() => setNotice('返回首页')}
            onToggle={() => {
              setSelected((v) => !v);
              setNotice(selected ? '收起通知栏' : '打开通知栏覆盖层');
            }}
            expanded={selected}
            noticeCount={2}
          />
          <div>
            <p>通知栏的收起态</p>
            <p className="ts-muted">完整覆盖、返回与内容联动见交互样板。</p>
            {selected && (
              <div className="story-mini-peek">
                <NotificationRail>
                  <NoticeSample />
                </NotificationRail>
              </div>
            )}
          </div>
        </div>
      );
      break;
    case 'battlefield':
      example = (
        <BattlefieldCard
          title="灯塔项目"
          summary="验证客户能否在没有陪同的情况下持续使用天枢。"
          urgency="attention"
          health="watch"
          reason="三次客户访谈中，两位仍需要人员辅助完成决策确认。"
          decision="本周优先补齐自主使用，还是扩展 DRI 场景？"
          progress={62}
          onOpen={() => setNotice('打开灯塔项目详情')}
        />
      );
      break;
    case 'dock':
      example = (
        <div className="story-dock">
          <ConversationDock
            value={value}
            onChange={setValue}
            onSend={submit}
            caption={notice}
            voiceLabel="体验语音入口"
            voiceHint="演示入口 · 未连接麦克风"
            onVoice={() => setNotice('语音尚未接入；此示例没有录音。')}
            onHistory={() => setNotice('记录接口示例：由消费应用接入')}
          />
        </div>
      );
      break;
    case 'composer':
      example = (
        <ContextComposer context="灯塔项目" value={value} onChange={setValue} onSend={submit} />
      );
      break;
    case 'evidence':
      example = (
        <EvidenceItem
          title="客户试用记录"
          source="客户访谈"
          date="9月16日"
          excerpt={'客户可以独立阅读判断。\n决策确认仍需要说明。'}
          supports="需要简化确认入口。"
          limitation="仅三位受访者。"
          status="verified"
        />
      );
      break;
    case 'confirmation':
      example = (
        <VersionConfirmation
          version="3"
          summary="优先验证客户自主使用。"
          state={confirmed ? 'confirmed' : 'pending'}
          onConfirm={() => setConfirmed(true)}
        />
      );
      break;
    case 'state':
      example = (
        <StatePanel
          state={selected ? 'empty' : 'error'}
          title={selected ? '暂无待处理事项' : '材料暂未加载'}
          onRetry={() => setSelected(true)}
        >
          草稿保留，可稍后继续。
        </StatePanel>
      );
      break;
  }
  return (
    <div className="story-example">
      {example}
      {state}
    </div>
  );
}
