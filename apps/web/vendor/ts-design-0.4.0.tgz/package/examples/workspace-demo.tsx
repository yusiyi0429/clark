// Published from site/workspace-demo.tsx; validated with the library's typecheck.
import { useEffect, useState } from 'react';
import {
  ActionButton,
  BattlefieldCard,
  ContextComposer,
  ConversationDock,
  EvidenceItem,
  NoticeCard,
  StatusBadge,
  TianshuTheme,
  VersionConfirmation,
  WorkspaceShell,
  useDetailNavigation,
  type ThemeMode,
} from 'ts-design';
import { Button, Card, ToggleButton, ToggleButtonGroup } from 'ts-design/primitives';
const examples = {
  launch: {
    title: '灯塔项目战场',
    summary: '客户 DRI 没有参与，交付承诺也没定稿，本月的客户验证启动不了。',
    decision: 'CEO Agent 与 DRI Agent 应该捆绑销售还是分别切入？',
  },
  growth: {
    title: 'TokenOps战场',
    summary: '样本核验按期，但客户愿不愿意付费还没有证据。',
    decision: '成本可见应继续支持内部验证，还是开始外部付费试点？',
  },
};
export function WorkspaceDemo() {
  const [theme, setTheme] = useState<ThemeMode>('light');
  const [role, setRole] = useState<'CEO' | 'DRI'>('CEO');
  const [drafts, setDrafts] = useState<Record<string, string>>({});
  const [messages, setMessages] = useState<Record<string, string[]>>({});
  const [confirmed, setConfirmed] = useState(false);
  const [mode, setMode] = useState<'decisions' | 'progress'>('decisions');
  const [caption, setCaption] = useState('');
  const { detailId, open, close } = useDetailNavigation();
  useEffect(() => {
    const receive = (event: MessageEvent) => {
      if (
        event.origin !== location.origin ||
        event.source !== window.parent ||
        event.data?.type !== 'tianshu-preview'
      )
        return;
      if (event.data.theme === 'light' || event.data.theme === 'dark') setTheme(event.data.theme);
      if (event.data.role === 'CEO' || event.data.role === 'DRI') setRole(event.data.role);
      if (event.data.reset) {
        setDrafts({});
        setMessages({});
        setConfirmed(false);
        close();
      }
    };
    window.addEventListener('message', receive);
    window.parent.postMessage({ type: 'tianshu-preview-ready' }, location.origin);
    return () => window.removeEventListener('message', receive);
  }, [close]);
  const activeId = detailId && detailId in examples ? (detailId as keyof typeof examples) : null;
  const item = activeId ? examples[activeId] : null;
  const sidebar = (
    <>
      <NoticeCard
        category="issue"
        title="CEO / DRI 的交付范围需要明确"
        summary="客户希望确认是否需要 DRI 参与，以及首版承诺包含哪些能力。"
        status="待决策"
        tone="warning"
        meta="今天 09:20"
        isSelected={activeId === 'launch'}
        onOpen={(source) => open('launch', source)}
      />
      <NoticeCard
        category="meeting"
        title="九月经营会议"
        summary="围绕交付优先级与增长效率，对齐下一步。"
        status="待预审"
        meta="明天 10:00"
        onOpen={(source) => open('growth', source)}
      />
      <NoticeCard
        category="decision"
        title="核心客户支持方案"
        summary="核对会后决策，确认责任人和截止时间。"
        status={confirmed ? '已确认' : '待确认'}
        tone={confirmed ? 'success' : 'info'}
        onOpen={(source) => open('launch', source)}
      />
    </>
  );
  return (
    <TianshuTheme theme={theme}>
      <WorkspaceShell
        roleLabel={`${role} 工作台 · 示例数据`}
        sidebar={sidebar}
        noticeCount={3}
        onCloseDetail={close}
        dock={
          <ConversationDock
            context={item?.title ?? '全局工作区'}
            value={drafts[activeId ?? 'global'] ?? ''}
            onChange={(value) =>
              setDrafts((current) => ({ ...current, [activeId ?? 'global']: value }))
            }
            onSend={(value) => {
              setCaption('已保存到本次演示：' + value);
              setMessages((current) => ({
                ...current,
                [activeId ?? 'global']: [...(current[activeId ?? 'global'] ?? []), value],
              }));
              setDrafts((current) => ({ ...current, [activeId ?? 'global']: '' }));
            }}
            caption={caption}
            voiceLabel="体验语音入口"
            voiceHint="演示入口 · 未连接麦克风"
            onVoice={() => setCaption('语音尚未接入；此演示没有录音。请使用键盘输入。')}
            onHistory={() =>
              setCaption(
                messages[activeId ?? 'global']?.length
                  ? '本次演示记录：' + messages[activeId ?? 'global'].join('；')
                  : '当前讨论暂无演示记录',
              )
            }
          />
        }
        tabletOverview={
          <>
            <div className="demo-intro">
              <p className="ts-eyebrow">双屏 · 阅读模式</p>
              <h1>今天需要读完的材料</h1>
            </div>
            <div className="demo-reading-desk">
              <Card>
                <Card.Header>
                  <Card.Title>01 · 会前材料</Card.Title>
                  <Card.Description>今天的会议</Card.Description>
                </Card.Header>
                <Card.Content>
                  <h3>CEO / DRI 战略协同会议</h3>
                  <p>围绕客户验证、交付边界与 DRI 参与，明确需要决策的事项。</p>
                  <Button onPress={() => open('launch')}>阅读灯塔项目材料</Button>
                  <Button variant="secondary" onPress={() => open('growth')}>
                    阅读 TokenOps 材料
                  </Button>
                </Card.Content>
              </Card>
              <Card>
                <Card.Header>
                  <Card.Title>02 · 本月 Outcome / Mission</Card.Title>
                  <Card.Description>9 月协商稿</Card.Description>
                </Card.Header>
                <Card.Content>
                  <h3>验证持续使用，以及从共识到负责人行动的闭环</h3>
                  <p>灯塔项目：跑通内部真实使用，并明确客户持续使用和 DRI 参与的验证方式。</p>
                  <p>TokenOps：选定真实用量样本，明确节省价值与客户采购意愿。</p>
                  <Button variant="secondary" onPress={() => open('launch')}>
                    打开月度协商稿
                  </Button>
                </Card.Content>
              </Card>
            </div>
          </>
        }

        detail={
          item && activeId
            ? {
                id: activeId,
                title: item.title,
                subtitle: role === 'CEO' ? '战略问题 / 当前判断' : 'Mission / 推进与反馈',
                children: (
                  <>
                    <section className="demo-reading">
                      <StatusBadge tone="warning">需要明确取舍</StatusBadge>
                      <h2>当前判断</h2>
                      <p>{item.summary}</p>
                      <h3>本次要定什么</h3>
                      <p>{item.decision}</p>
                    </section>
                    <EvidenceItem
                      title="客户验收排期"
                      source="交付团队周报"
                      date="2026-09-16"
                      status="verified"
                      excerpt={'客户 A 计划于周五完成验收。\n客户 B 的关键接口仍有两项待联调。'}
                      supports="本周需要集中交付资源。"
                      limitation="排期仍需客户最终确认；示例数据不代表真实业务。"
                    />
                    {role === 'DRI' && (
                      <section className="demo-reading">
                        <h2>本周交付</h2>
                        <ul>
                          <li>已交付：第一轮集成测试记录</li>
                          <li>仍缺：两项接口验收与客户签字</li>
                          <li>下一步：周四前完成联合联调</li>
                        </ul>
                      </section>
                    )}
                    <VersionConfirmation
                      version="2"
                      summary="先保障核心客户验收；新增需求另排时间。"
                      state={confirmed ? 'confirmed' : 'pending'}
                      onConfirm={() => setConfirmed(true)}
                    />
                    {!!messages[activeId]?.length && (
                      <div className="demo-messages" aria-live="polite">
                        {messages[activeId].map((message, index) => (
                          <p key={index}>
                            <strong>已提交示例消息：</strong>
                            {message}
                          </p>
                        ))}
                      </div>
                    )}
                    <ContextComposer
                      context={item.title}
                      value={drafts[activeId] ?? ''}
                      onChange={(value) =>
                        setDrafts((current) => ({ ...current, [activeId]: value }))
                      }
                      onSend={(value) => {
                        setMessages((current) => ({
                          ...current,
                          [activeId]: [...(current[activeId] ?? []), value],
                        }));
                        setDrafts((current) => ({ ...current, [activeId]: '' }));
                      }}
                    />
                  </>
                ),
              }
            : null
        }
      >
        <div className="demo-intro">
          <p className="ts-eyebrow">天枢 · {role} 工作区</p>
          <h1>{role === 'CEO' ? '公司全局' : '我的承诺与推进'}</h1>
        </div>
        <div className="demo-top">
          <Card className="demo-strategy">
            <Card.Header>
              <Card.Title>公司战略议题</Card.Title>
            </Card.Header>
            <Card.Content>
              <Button variant="ghost" onPress={() => open('launch')}>
                交付力量先支持灯塔，还是 TokenOps？ →
              </Button>
              <Button variant="ghost" onPress={() => open('growth')}>
                未来一年，公司首先靠 TKOS，还是 Token 业务形成增长？ →
              </Button>
              <Button variant="ghost" onPress={() => open('growth')}>
                TokenHub 应继续作为内部底座，还是成为独立业务？ →
              </Button>
            </Card.Content>
          </Card>
          <Card>
            <Card.Header>
              <Card.Title>雷达信号</Card.Title>
              <Card.Description>看看外面的变化</Card.Description>
            </Card.Header>
            <Card.Content>
              <div className="demo-radar" aria-hidden="true">
                <span />
                <span />
                <i />
              </div>
              <Button variant="ghost" onPress={() => open('growth')}>
                查看信号与依据 →
              </Button>
            </Card.Content>
          </Card>
        </div>
        <div className="demo-toolbar">
          <h2>战场</h2>
          <ToggleButtonGroup
            selectionMode="single"
            disallowEmptySelection
            selectedKeys={[mode]}
            onSelectionChange={(keys) => {
              const next = [...keys][0];
              if (next === 'decisions' || next === 'progress') setMode(next);
            }}
            aria-label="战场展示方式"
          >
            <ToggleButton id="decisions">待决策</ToggleButton>
            <ToggleButton id="progress">进展</ToggleButton>
          </ToggleButtonGroup>
        </div>
        <div className="demo-cards">
          <BattlefieldCard
            {...examples.launch}
            mode={mode}
            onModeChange={setMode}
            progress={58}
            urgency="urgent"
            health="risk"
            reason="客户验收窗口将在 3 天后到达。"
            onOpen={(source) => open('launch', source)}
          />
          <BattlefieldCard
            {...examples.growth}
            mode={mode}
            onModeChange={setMode}
            progress={65}
            urgency="attention"
            health="watch"
            reason="有效转化连续两周低于预期。"
            onOpen={(source) => open('growth', source)}
          />
        </div>
        <p className="demo-notice">交互样板 · 本地示例数据。业务确认、语音和检索由应用接入。</p>
      </WorkspaceShell>
    </TianshuTheme>
  );
}
