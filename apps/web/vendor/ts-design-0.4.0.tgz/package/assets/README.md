# 图形资产

`brand/tianshu-concept-v7.svg` 复制自用户现有概念版 `clark-main/public/brand/tkos-tianshu-fluid-hub-mark-v7.svg`，内容未更改。本版保留其“概念 v7”身份，不宣布它是最终品牌标志。

功能图标通过 lucide-react 使用，默认20px、strokeWidth=1.75；图标按钮必须有可读名称。Lucide 采用 ISC 许可证，完整许可随依赖提供。

品牌资产默认仅供天枢内部使用；新增图形须说明来源、用途和授权。参考截图中的第三方品牌与页面未复制到本仓库。

## 概念版通知资产

brand/tianshu-notification-wallpaper-v1.webp 与 tianshu-flow-lock-v2.webp 从用户现有概念版复用，作为历史资产存档。v0.4 通知栏改用 token 驱动的克制深蓝材质，阅读页不使用这些壁纸。保留现有权属，不宣称它们是 HeroUI 资产或授予第三方许可。
