# 使用天枢设计系统的 Agent 入口

安装包的版本是本次实现的依据。先查项目 lockfile，禁止凭记忆混用 HeroUI v2/v3 API。

## 第一次接入

1. 安装团队提供的 `.tgz`，或已配置私有源中的 `ts-design`。本仓库尚未发布到公共 npm，不要把同名第三方包当成它。
2. 运行 `npx --no-install ts-design init`：仅把本文件的入口添加到项目 AGENTS.md / CLAUDE.md，保留原文，可重复执行。安装本身不运行写入脚本。
3. 运行 `npx --no-install ts-design doctor`：检查 React/HeroUI/Tailwind 版本、全局 CSS 引入与规则入口。
4. 按 README 配置 Tailwind 4，导入一次 styles.css，根部使用 TianshuTheme。弹层内容使用 TianshuPortalTheme。

## 按任务查资料

| 想做什么                           | 先读什么                                                                  |
| ---------------------------------- | ------------------------------------------------------------------------- |
| 选控件                             | `components.json`，或 `ts-design list` / `info Slider`                    |
| 正确写 API                         | 对应 `.d.ts`；`examples/component-stories.tsx` 是经过类型检查的实际展示源 |
| 改颜色                             | `docs/principles.md` 与 `tokens/`，不编辑 dist                            |
| 通知栏、翻面、详情返回、输入条形变 | `docs/interaction.md`                                                     |
| 从已有概念版迁移                   | `docs/migration.md` 与 `docs/hero-audit.md`                               |
| 完成后检查                         | 本页验收清单与 `docs/verification.md`                                     |

## 组件选择顺序

1. 普通按钮、输入、多选、滑块、页签、卡片、状态、提示、弹窗与抽屉：从 `ts-design/primitives` 使用原版 HeroUI API。无须重新封装一套。
2. 天枢已有组合：从主入口使用 NoticeCard、BattlefieldCard、EvidenceItem、ConversationDock 等。
3. 只有通知材质与玻璃标题、rail/strip 与详情空间协调、源卡片形变、3D 翻面、输入条形变由天枢自研；其中的控件仍用 HeroUI。
4. 新需求先找可组合的 HeroUI 组件。确实缺失时再实现，并补独立交互示例、边界和验证。不得用 div + click 重新实现标准按钮或滑块。

## 必须遵守

- 使用主题语义变量。当前品牌由用户指定：`#3A83F7` 配白字 `#FFFFFF`，辅助渐变色 `#3C66BF`。亮色填充不直接当正文链接色。
- 以 docs/principles.md v2 为准：手机 > 平板 >> 桌面，语音主操作，历史/键盘次级。阅读近白、深色中性，毛玻璃限功能层；健康只用局部淡洗色、点与文字，中性边框。最新用户授权覆盖旧“壁纸/整卡状态底色保留”约定。
- 健康红黄绿、未知灰，独立于紧急程度与确认；不推断缺失业务状态。品牌蓝不扩散成全站底色。手机首页保留 dock、上下文和安全区空间。
- 页面只控制布局，禁止全局 `.shell button {…}` 覆盖 HeroUI 的行为、状态与外观。特殊内容表面必须有具名作用域和原因。
- 消费应用持有权限、草稿、URL、业务确认与语音能力；动画结束不等于确认，打开不等于已处理。
- 正常用户不选设备。当前概念基准：≤690 通知首页；691–1000 双页阅读；宽屏全局战场。打开详情都保留窄条，peek 覆盖正文而不挤压。
- 保留 DOM ref、data-*、焦点返回、Escape、浏览器返回与中文输入法。不改已验证的 View Transition / FLIP 测量节点。
- 无完整后端时示例明确采用本地数据，不触发真实发送、发布、语音费用。

## 验收

类型检查 → 相关行为测试 → 390/834/1440 宽度浏览器检查。检查按钮真实响应、Slider 键盘操作、主题和 portal、草稿保留、窄条覆盖、翻面 inert 与焦点、减少动效。手机模拟不等于真机。

遵循项目已有检查命令；库自身执行 `npm run check`、`npm run test:e2e`。报告覆盖范围与实际缺口，不把构建通过写成视觉一致。
